package models;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class ApiBean {
	
	private static Document convertStringToXMLDocument(String xmlString) {
		// Parser that produces DOM object trees from XML content
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		// API to obtain DOM Document instance
		DocumentBuilder builder = null;
		try {
			// Create DocumentBuilder with default configuration
			builder = factory.newDocumentBuilder();

			// Parse the content to Document object
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	

	
	
	public ArrayList<String> removeDuplicates(ArrayList<String> list){
		
		return (ArrayList<String>) list.stream() 
	            .distinct() 
	            .collect(Collectors.toList()); 
	}
	
	
	
	
	
	public ArrayList<String> createListOfNodesContent(Document doc, String tagName) {
		

		
		//normalize the XML response
		doc.getDocumentElement().normalize();
		// check that the XML response is OK by getting the Root element 
		//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

		// Create a Node list that gets everything in and under the "clouds" tag  
		//NodeList nList = doc.getElementsByTagName("clouds");
		NodeList nList = doc.getElementsByTagName("tagName");
	
		
	
		//System.out.print(nList.getLength());
	
		
		// Instantiate the list busses
		ArrayList<String> bussList = new ArrayList<String>();
		
		
		
		
		
		
		
		
		// loop through the content of the tag nList.getLength()
		for (int temp = 0; temp < nList.getLength(); temp++) {
			
			// Save a node of the current list id 
			Node node = nList.item(temp);
			//Node node2 = nList2.item(temp);
			if (node.getNodeType() == Node.ELEMENT_NODE) {

				// set the current node as an Element
				Element eElement = (Element) node;
				//Element eElement2 = (Element) node2;
				// get the content of an attribute in element
				// and print it out to the client 
			//	System.out.println("getTextContent: " + eElement.getTextContent());
				//System.out.println("getTextContent: " + eElement2.getTextContent());
				//System.out.println("node Name: " + eElement.getNodeName() );
				
				bussList.add(temp, eElement.getTextContent());
				
				
				
				
				
			}
			}
		return bussList;

		
	}
	
	
	public String createApiResponse(String inLine, BufferedReader in) {
		// a String to save the full response to use later
		String ApiResponse = "";

		// loop through the whole response
		try {
			while ((inLine = in.readLine()) != null) {
				
				//System.out.println(inputLine);
				// Save the temp line into the full response
				ApiResponse += inLine;
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		//in.close();
	
		return ApiResponse;
		
	}

}
